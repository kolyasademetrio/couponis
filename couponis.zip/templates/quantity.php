<div class="good__qtyWrap">
    <input type="number">
    <span class="good__qtyBtn good__qtyPlus">+</span>
    <span class="good__qtyBtn good__qtyMinus">-</span>
</div>