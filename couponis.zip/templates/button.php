<?php

class Button
{
    public static function render($text){

        return '<button class="shoppingcart__btnSubmit">' . $text . '</button>';

    }
}